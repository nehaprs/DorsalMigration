```python
import scanpy as sc
import scvelo as scv
import numpy as np
```


```python
adata = sc.read_h5ad('/home/neha/dorsalmigration/velocity/velocity/results/adatasam_with_velocity.h5ad')
```


```python
scv.pp.filter_and_normalize(adata)
```

    WARNING: Did not normalize X as it looks processed already. To enforce normalization, set `enforce=True`.
    WARNING: Did not normalize spliced as it looks processed already. To enforce normalization, set `enforce=True`.
    WARNING: Did not normalize unspliced as it looks processed already. To enforce normalization, set `enforce=True`.
    WARNING: adata.X seems to be already log-transformed.
    Logarithmized X.


    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/preprocessing/utils.py:705: DeprecationWarning: `log1p` is deprecated since scVelo v0.3.0 and will be removed in a future version. Please use `log1p` from `scanpy.pp` instead.
      log1p(adata)



```python
scv.pp.moments(adata)
```

    /tmp/ipykernel_556/3618267578.py:1: DeprecationWarning: Automatic neighbor calculation is deprecated since scvelo==0.4.0 and will be removed in a future version of scVelo. Please compute neighbors first with Scanpy.
      scv.pp.moments(adata)
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/preprocessing/moments.py:71: DeprecationWarning: `neighbors` is deprecated since scvelo==0.4.0 and will be removed in a future version of scVelo. Please compute neighbors with Scanpy.
      neighbors(
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/preprocessing/neighbors.py:233: DeprecationWarning: Automatic computation of PCA is deprecated since scvelo==0.4.0 and will be removed in a future version of scVelo. Please compute PCA with Scanpy first.
      _set_pca(adata=adata, n_pcs=n_pcs, use_highly_variable=use_highly_variable)


    computing neighbors
        finished (0:00:27) --> added 
        'distances' and 'connectivities', weighted adjacency matrices (adata.obsp)
    computing moments based on connectivities
        finished (0:00:33) --> added 
        'Ms' and 'Mu', moments of un/spliced abundances (adata.layers)



```python
scv.tl.velocity(adata)
```

    computing velocities


    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/tools/optimization.py:184: DeprecationWarning: Conversion of an array with ndim > 0 to a scalar is deprecated, and will error in future. Ensure you extract a single element from your array before performing this operation. (Deprecated NumPy 1.25.)
      gamma[i] = np.linalg.pinv(A.T.dot(A)).dot(A.T.dot(y[:, i]))


        finished (0:02:53) --> added 
        'velocity', velocity vectors for each individual cell (adata.layers)



```python
scv.tl.velocity_graph(adata, n_jobs=1)
```

    computing velocity graph (using 1/8 cores)
        finished (0:05:19) --> added 
        'velocity_graph', sparse matrix with cosine correlations (adata.uns)



```python
scv.set_figure_params()
```


```python
adata.obs
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>orig.ident</th>
      <th>nCount_RNA</th>
      <th>nFeature_RNA</th>
      <th>percent.mt</th>
      <th>RNA_snn_res.0</th>
      <th>seurat_clusters</th>
      <th>RNA_snn_res.0.1</th>
      <th>RNA_snn_res.0.2</th>
      <th>RNA_snn_res.0.3</th>
      <th>RNA_snn_res.0.4</th>
      <th>...</th>
      <th>batch</th>
      <th>stage</th>
      <th>orig_cluster</th>
      <th>ident</th>
      <th>loom_batch</th>
      <th>initial_size_unspliced</th>
      <th>initial_size_spliced</th>
      <th>initial_size</th>
      <th>n_counts</th>
      <th>velocity_self_transition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>s17_AAACCAAAGCATGGGA</th>
      <td>dorsal migration</td>
      <td>1204.0</td>
      <td>669</td>
      <td>0.0</td>
      <td>0</td>
      <td>8</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>6</td>
      <td>...</td>
      <td>s17</td>
      <td>s17</td>
      <td>s17_8</td>
      <td>8</td>
      <td>0</td>
      <td>139.0</td>
      <td>933.0</td>
      <td>933.0</td>
      <td>563.797008</td>
      <td>0.205446</td>
    </tr>
    <tr>
      <th>s17_AAACCAAAGTAGACCC</th>
      <td>dorsal migration</td>
      <td>10528.0</td>
      <td>2950</td>
      <td>0.0</td>
      <td>0</td>
      <td>5</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>s17</td>
      <td>s17</td>
      <td>s17_2</td>
      <td>5</td>
      <td>0</td>
      <td>1433.0</td>
      <td>8243.0</td>
      <td>8243.0</td>
      <td>717.988474</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>s17_AAACCAAAGTAGCTGC</th>
      <td>dorsal migration</td>
      <td>1415.0</td>
      <td>681</td>
      <td>0.0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>s17</td>
      <td>s17</td>
      <td>s17_0</td>
      <td>2</td>
      <td>0</td>
      <td>170.0</td>
      <td>1142.0</td>
      <td>1142.0</td>
      <td>477.360001</td>
      <td>0.249531</td>
    </tr>
    <tr>
      <th>s17_AAACCAAAGTCATCTC</th>
      <td>dorsal migration</td>
      <td>8465.0</td>
      <td>2362</td>
      <td>0.0</td>
      <td>0</td>
      <td>5</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>s17</td>
      <td>s17</td>
      <td>s17_2</td>
      <td>5</td>
      <td>0</td>
      <td>777.0</td>
      <td>6979.0</td>
      <td>6979.0</td>
      <td>660.563742</td>
      <td>0.165052</td>
    </tr>
    <tr>
      <th>s17_AAACCAAAGTCGACGT</th>
      <td>dorsal migration</td>
      <td>18104.0</td>
      <td>3799</td>
      <td>0.0</td>
      <td>0</td>
      <td>5</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>s17</td>
      <td>s17</td>
      <td>s17_2</td>
      <td>5</td>
      <td>0</td>
      <td>1758.0</td>
      <td>14725.0</td>
      <td>14725.0</td>
      <td>699.265142</td>
      <td>0.092140</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>s19_TGTGTTGAGCATCAAT</th>
      <td>dorsal migration</td>
      <td>981.0</td>
      <td>636</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>...</td>
      <td>s19</td>
      <td>s19</td>
      <td>s19_10</td>
      <td>1</td>
      <td>1</td>
      <td>117.0</td>
      <td>786.0</td>
      <td>786.0</td>
      <td>586.531701</td>
      <td>0.130916</td>
    </tr>
    <tr>
      <th>s19_TGTGTTGAGCCTAGCG</th>
      <td>dorsal migration</td>
      <td>835.0</td>
      <td>535</td>
      <td>0.0</td>
      <td>0</td>
      <td>13</td>
      <td>3</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>...</td>
      <td>s19</td>
      <td>s19</td>
      <td>s19_5</td>
      <td>13</td>
      <td>1</td>
      <td>113.0</td>
      <td>667.0</td>
      <td>667.0</td>
      <td>554.581148</td>
      <td>0.207756</td>
    </tr>
    <tr>
      <th>s19_TGTGTTGAGGTCGTTA</th>
      <td>dorsal migration</td>
      <td>760.0</td>
      <td>496</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>s19</td>
      <td>s19</td>
      <td>s19_0</td>
      <td>1</td>
      <td>1</td>
      <td>96.0</td>
      <td>601.0</td>
      <td>601.0</td>
      <td>533.067739</td>
      <td>0.197446</td>
    </tr>
    <tr>
      <th>s19_TGTGTTGAGGTTGCTA</th>
      <td>dorsal migration</td>
      <td>1175.0</td>
      <td>740</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>s19</td>
      <td>s19</td>
      <td>s19_1</td>
      <td>1</td>
      <td>1</td>
      <td>121.0</td>
      <td>955.0</td>
      <td>955.0</td>
      <td>608.847731</td>
      <td>0.097224</td>
    </tr>
    <tr>
      <th>s19_TGTGTTGAGGTTGGAG</th>
      <td>dorsal migration</td>
      <td>633.0</td>
      <td>418</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>s19</td>
      <td>s19</td>
      <td>s19_0</td>
      <td>1</td>
      <td>1</td>
      <td>77.0</td>
      <td>515.0</td>
      <td>515.0</td>
      <td>492.614337</td>
      <td>0.164185</td>
    </tr>
  </tbody>
</table>
<p>36507 rows × 37 columns</p>
</div>




```python
adata.obsm_keys()
```




    ['PCA', 'UMAP', 'X_pca']




```python
adata.obsm["UMAP"].shape[0] == adata.n_obs

```




    True




```python
print(type(adata.obsm["X_UMAP"]), getattr(adata.obsm["X_UMAP"], "shape", None))
```

    <class 'pandas.core.frame.DataFrame'> (36507, 2)



```python
X = adata.obsm["X_UMAP"]
if hasattr(X, "loc"):  # pandas DataFrame
    X = X.loc[adata.obs_names].to_numpy()

adata.obsm["X_umap"] = np.asarray(X)
```


```python
scv.pl.velocity_embedding(adata, basis="umap", color = "orig_cluster")

```

    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])



    
![png](output_12_1.png)
    



```python
scv.pl.velocity_embedding_grid(adata, basis="umap", color = "orig_cluster")
```

    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])



    
![png](output_13_1.png)
    



```python
scv.pl.velocity_embedding_stream(adata, basis="umap", color = "orig_cluster",
    legend_loc="none",
    size=20,
    alpha=0.6)
```

    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])



    
![png](output_14_1.png)
    



```python
scv.pl.velocity(adata, ['foxd3', 'zic3'])
```


    
![png](output_15_0.png)
    



```python
scv.tl.velocity_confidence(adata)
keys = 'velocity_length', 'velocity_confidence'
scv.pl.scatter(adata, c = keys, perc = [5,95])
```

    --> added 'velocity_length' (adata.obs)
    --> added 'velocity_confidence' (adata.obs)
    --> added 'velocity_confidence_transition' (adata.obs)


    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])



    
![png](output_16_2.png)
    



```python
scv.tl.velocity_pseudotime(adata)
scv.pl.scatter(adata, color = 'velocity_pseudotime')
```

    computing terminal states
        identified 6 regions of root cells and 4 regions of end points .
        finished (0:00:07) --> added
        'root_cells', root cells of Markov diffusion process (adata.obs)
        'end_points', end points of Markov diffusion process (adata.obs)


    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])



    
![png](output_17_2.png)
    



```python
scv.settings.verbosity = 2

```


```python
adata.n_obs, adata.n_vars

```




    (36507, 22829)




```python
type(adata.X)
type(adata.layers["spliced"])
type(adata.layers["unspliced"])

```




    scipy.sparse._csr.csr_matrix




```python
scv.tl.recover_dynamics(
    adata,
    n_top_genes=2000,
    n_jobs=-1,
    show_progress_bar=False
)

scv.tl.velocity(adata, mode = 'dynamical')

```

    recovering dynamics (using 8/8 cores)
        finished (1:39:44)
    computing velocities
        finished (0:39:06)
    computing velocity graph (using 1/8 cores)



    ---------------------------------------------------------------------------

    OSError                                   Traceback (most recent call last)

    Cell In[38], line 9
          1 scv.tl.recover_dynamics(
          2     adata,
          3     n_top_genes=2000,
          4     n_jobs=-1,
          5     show_progress_bar=False
          6 )
          8 scv.tl.velocity(adata, mode = 'dynamical')
    ----> 9 scv.tl.velocity_graph(adata)
         10 scv.pl.velocity_embedding_stream(adata, basis = 'umap', color = "orig_cluster",
         11     legend_loc="none")


    File ~/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/tools/velocity_graph.py:379, in velocity_graph(data, vkey, xkey, tkey, basis, n_neighbors, n_recurse_neighbors, random_neighbors_at_max, sqrt_transform, variance_stabilization, gene_subset, compute_uncertainties, approx, mode_neighbors, copy, n_jobs, backend, show_progress_bar)
        375 n_jobs = get_n_jobs(n_jobs=n_jobs)
        376 logg.info(
        377     f"computing velocity graph (using {n_jobs}/{os.cpu_count()} cores)", r=True
        378 )
    --> 379 vgraph.compute_cosines(
        380     n_jobs=n_jobs, backend=backend, show_progress_bar=show_progress_bar
        381 )
        383 adata.uns[f"{vkey}_graph"] = vgraph.graph
        384 adata.uns[f"{vkey}_graph_neg"] = vgraph.graph_neg


    File ~/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/tools/velocity_graph.py:187, in VelocityGraph.compute_cosines(self, n_jobs, backend, show_progress_bar)
        184 n_obs = self.X.shape[0]
        186 # TODO: Use batches and vectorize calculation of dX in self._calculate_cosines
    --> 187 res = parallelize(
        188     self._compute_cosines,
        189     range(self.X.shape[0]),
        190     n_jobs=n_jobs,
        191     unit="cells",
        192     backend=backend,
        193     as_array=False,
        194     show_progress_bar=show_progress_bar,
        195 )()
        196 uncertainties, vals, rows, cols = map(_flatten, zip(*res))
        198 vals = np.hstack(vals)


    File ~/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/core/_parallelize.py:121, in parallelize.<locals>.wrapper(*args, **kwargs)
        119 if pass_queue and show_progress_bar:
        120     pbar = None if tqdm is None else tqdm(total=col_len, unit=unit)
    --> 121     queue = Manager().Queue()
        122     thread = Thread(target=update, args=(pbar, queue, len(collections)))
        123     thread.start()


    File ~/miniconda3/envs/scvelo_cellrank/lib/python3.10/multiprocessing/context.py:57, in BaseContext.Manager(self)
         55 from .managers import SyncManager
         56 m = SyncManager(ctx=self.get_context())
    ---> 57 m.start()
         58 return m


    File ~/miniconda3/envs/scvelo_cellrank/lib/python3.10/multiprocessing/managers.py:562, in BaseManager.start(self, initializer, initargs)
        560 ident = ':'.join(str(i) for i in self._process._identity)
        561 self._process.name = type(self).__name__  + '-' + ident
    --> 562 self._process.start()
        564 # get address of server
        565 writer.close()


    File ~/miniconda3/envs/scvelo_cellrank/lib/python3.10/multiprocessing/process.py:121, in BaseProcess.start(self)
        118 assert not _current_process._config.get('daemon'), \
        119        'daemonic processes are not allowed to have children'
        120 _cleanup()
    --> 121 self._popen = self._Popen(self)
        122 self._sentinel = self._popen.sentinel
        123 # Avoid a refcycle if the target function holds an indirect
        124 # reference to the process object (see bpo-30775)


    File ~/miniconda3/envs/scvelo_cellrank/lib/python3.10/multiprocessing/context.py:281, in ForkProcess._Popen(process_obj)
        278 @staticmethod
        279 def _Popen(process_obj):
        280     from .popen_fork import Popen
    --> 281     return Popen(process_obj)


    File ~/miniconda3/envs/scvelo_cellrank/lib/python3.10/multiprocessing/popen_fork.py:19, in Popen.__init__(self, process_obj)
         17 self.returncode = None
         18 self.finalizer = None
    ---> 19 self._launch(process_obj)


    File ~/miniconda3/envs/scvelo_cellrank/lib/python3.10/multiprocessing/popen_fork.py:66, in Popen._launch(self, process_obj)
         64 parent_r, child_w = os.pipe()
         65 child_r, parent_w = os.pipe()
    ---> 66 self.pid = os.fork()
         67 if self.pid == 0:
         68     try:


    OSError: [Errno 12] Cannot allocate memory



```python

scv.pl.velocity_embedding_stream(adata, basis = 'umap', color = "orig_cluster",
    legend_loc="none")
```

    computing velocity embedding
        finished (0:00:18)


    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])
    /home/neha/miniconda3/envs/scvelo_cellrank/lib/python3.10/site-packages/scvelo/plotting/utils.py:68: DeprecationWarning: is_categorical_dtype is deprecated and will be removed in a future version. Use isinstance(dtype, pd.CategoricalDtype) instead
      return isinstance(c, str) and c in data.obs.keys() and cat(data.obs[c])



    
![png](output_22_2.png)
    



```python
scv.tl.latent_time(adata)
scv.pl.scatter(adata, color='latent_time', color_map='gnuplot', size=80)
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[1], line 1
    ----> 1 scv.tl.latent_time(adata)
          2 scv.pl.scatter(adata, color='latent_time', color_map='gnuplot', size=80)


    NameError: name 'scv' is not defined



```python

```


```python
#color s17_18
adata.obs["highlight_s17_dm"] = np.where(
    adata.obs["orig_cluster"] == "s17_18",
    "s17_18",
    "other"
)

scv.pl.velocity_embedding_stream(
    adata,
    basis="umap",
    color="highlight_s17_dm",
    palette={"s17_18": "red", "other": "lightgrey"},
    legend_loc="none",
    save = '/home/neha/dorsalmigration/velocity/velocity/results/sam/s17dm_dynamic.png'
)
```

    saving figure to file /home/neha/dorsalmigration/velocity/velocity/results/sam/s17dm_dynamic.png



    
![png](output_25_1.png)
    



```python
scv.pl.velocity_embedding_grid(adata, basis="umap", color = "orig_cluster",
                               save = '/home/neha/dorsalmigration/velocity/velocity/results/sam/grid_dynamic.png')
```

    saving figure to file /home/neha/dorsalmigration/velocity/velocity/results/sam/grid_dynamic.png



    
![png](output_26_1.png)
    



```python
scv.tl.velocity_confidence(adata)
keys = 'velocity_length', 'velocity_confidence'
scv.pl.scatter(adata, c = keys, perc = [5,95],
              save = '/home/neha/dorsalmigration/velocity/velocity/results/sam/velocity_confidence_dynamic.png')
```

    --> added 'velocity_length' (adata.obs)
    --> added 'velocity_confidence' (adata.obs)
    saving figure to file /home/neha/dorsalmigration/velocity/velocity/results/sam/velocity_confidence_dynamic.png



    
![png](output_27_1.png)
    



```python
#middle region without velocity lines: are unsoliced counts too low?
adata.obs["n_spliced"]   = np.ravel(adata.layers["spliced"].sum(axis=1))
adata.obs["n_unspliced"] = np.ravel(adata.layers["unspliced"].sum(axis=1))

# log-scale is easier to see
adata.obs["log1p_n_unspliced"] = np.log1p(adata.obs["n_unspliced"])
adata.obs["unspliced_frac"] = adata.obs["n_unspliced"] / (
    adata.obs["n_spliced"] + adata.obs["n_unspliced"] + 1e-8
)

scv.pl.scatter(adata, basis="umap", color="log1p_n_unspliced")
```


    
![png](output_28_0.png)
    



```python
scv.pl.velocity_embedding_stream(
    adata,
    basis="umap",
    min_mass=0.1,
    density=1
)
```


    
![png](output_29_0.png)
    



```python

```
